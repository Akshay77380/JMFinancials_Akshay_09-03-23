class RespRecType {
  static const List<int> validRecType = [
    65,
    66,
    67,
    68,
    69,
    70,
    71,
    72,
    73,
    74,
    75,
    76,
    77,
    78,
    79,
    80,
    81,
    82,
    83,
    84,
    85,
    86,
    87,
    88,
    89,
    90,
    97,
    98,
    99,
    100,
    101,
    102,
    103,
    104,
    105,
    106,
    107,
    108,
    109,
    110,
    111,
    112,
    113,
    114,
    115,
    116,
    117,
    118,
    119,
    120,
    121,
    122,
    49,
  ];
  static const int recType_A = 65;
  static const int recType_B = 66;
  static const int recType_C = 67;
  static const int recType_D = 68;
  static const int recType_E = 69;
  static const int recType_F = 70;
  static const int recType_G = 71;
  static const int recType_H = 72;
  static const int recType_I = 73;
  static const int recType_J = 74;
  static const int recType_K = 75;
  static const int recType_L = 76;
  static const int recType_M = 77;
  static const int recType_N = 78;
  static const int recType_O = 79;
  static const int recType_P = 80;
  static const int recType_Q = 81;
  static const int recType_R = 82;
  static const int recType_S = 83;
  static const int recType_T = 84;
  static const int recType_U = 85;
  static const int recType_V = 86;
  static const int recType_W = 87;
  static const int recType_X = 88;
  static const int recType_Y = 89;
  static const int recType_Z = 90;
  static const int recType_a = 97;
  static const int recType_b = 98;
  static const int recType_c = 99;
  static const int recType_d = 100;
  static const int recType_e = 101;
  static const int recType_f = 102;
  static const int recType_g = 103;
  static const int recType_h = 104;
  static const int recType_i = 105;
  static const int recType_j = 106;
  static const int recType_k = 107;
  static const int recType_l = 108;
  static const int recType_m = 109;
  static const int recType_n = 110;
  static const int recType_o = 111;
  static const int recType_p = 112;
  static const int recType_q = 113;
  static const int recType_r = 114;
  static const int recType_s = 115;
  static const int recType_t = 116;
  static const int recType_u = 117;
  static const int recType_v = 118;
  static const int recType_w = 119;
  static const int recType_x = 120;
  static const int recType_y = 121;
  static const int recType_z = 122;
  static const int recType_1 = 49;
}
