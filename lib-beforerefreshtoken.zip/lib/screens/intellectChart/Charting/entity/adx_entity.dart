mixin ADXEntity {
  //  Upper rail line
  List<double> Adxup; //double up;

//  Middle track
  List<double> Adxmb; //double mb;

//  Lower track
  List<double> Adxdn; //double dn;
}
