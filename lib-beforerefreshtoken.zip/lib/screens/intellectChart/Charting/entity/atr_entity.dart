mixin ATREntity {
  List<double> atr;
  List<double> tempATR;
}
