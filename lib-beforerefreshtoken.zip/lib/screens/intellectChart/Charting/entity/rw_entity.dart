mixin WREntity {
  List<double> r;
}
