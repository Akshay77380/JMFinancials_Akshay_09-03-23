import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:markets/controllers/fundtransactioncontroller.dart';
import 'package:markets/util/CommonFunctions.dart';
import '../../model/custom_processed.dart';
import '../../util/Dataconstants.dart';
import '../../util/Utils.dart';
import 'package:markets/model/jmModel/fundtransactionmodel.dart';

import '../watchlist/jmWatchlistScreen.dart';
import 'AddMoney.dart';

class PayDetails extends StatefulWidget {
  String status;
  // Detail details;
  CustomProcessed details;
  Datum fundTransactionModel;

  PayDetails({this.status, this.details, this.fundTransactionModel});

  @override
  State<PayDetails> createState() => _PayDetailsState();
}

class _PayDetailsState extends State<PayDetails> {
  @override
  void initState() {
    // TODO: implement initState
    getPaymentAccessToken();
    super.initState();
  }

  getPaymentAccessToken() async {
    var header = {"application": "Intellect"};
    var stringResponse = await CommonFunction.getPaymentAccessToken(header);
    var jsonResponse = jsonDecode(stringResponse);
    print("Get access token: ${jsonResponse}");
    Dataconstants.fundstoken = await jsonResponse['data'];
    await Dataconstants.bankDetailsController.getBankDetails();
    // print(Dataconstants.fundstoken);
    // getBankdetails();
    return Dataconstants.fundstoken;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          Spacer(),
          Card(
            margin: EdgeInsets.zero,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Pay Out Details",
                        style: Utils.fonts(size: 20.0),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.close),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "BANK",
                            style: Utils.fonts(
                                color: Utils.greyColor,
                                size: 15.0,
                                fontWeight: FontWeight.w400),
                          ),
                          Text(
                            widget.fundTransactionModel.bankName ?? "",
                            style: Utils.fonts(
                              fontWeight: FontWeight.w700,
                              size: 15.0,
                            ),
                          )
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            "Status",
                            style: Utils.fonts(
                                color: Utils.greyColor,
                                size: 15.0,
                                fontWeight: FontWeight.w400),
                          ),
                          Text(
                            // widget.status.toString().toUpperCase(),
                            widget.details.status.toString().toUpperCase(),
                            style: Utils.fonts(
                                fontWeight: FontWeight.w700,
                                size: 15.0,
                                color: widget.status.toString().toUpperCase() ==
                                        "PENDING"
                                    ? Utils.primaryColor
                                    : widget.status
                                                .toString()
                                                .trim()
                                                .toUpperCase() ==
                                            "CANCELLED"
                                        ? Utils.darkRedColor
                                        : Utils.darkGreenColor),
                          )
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: Utils.greyColor,
                          width: 1,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(15.0),
                        )),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Text("Amount",
                            style: Utils.fonts(
                                size: 15.0,
                                color: Utils.blackColor,
                                fontWeight: FontWeight.w700)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                                // widget.fundTransactionModel.status == "Pending"
                                //     ? "₹${widget.details.amount}"
                                //     : "₹${widget.fundTransactionModel.approvedAmount}",
                                // style: Utils.fonts(
                                //     size: 35.0,
                                //     color:
                                //         double.parse(widget.details.amount) < 0
                                //             ? Utils.darkRedColor
                                //             : double.parse(widget
                                //                         .fundTransactionModel
                                //                         .approvedAmount) <
                                //                     0
                                //                 ? Utils.darkRedColor
                                //                 : Utils.darkGreenColor,
                                //     fontWeight: FontWeight.w700)),
                                widget.details.status == "Pending"
                                    ? "₹${widget.details.totalAmount}"
                                    : widget.details.status == "Processed"
                                        ? "₹${widget.fundTransactionModel.approvedAmount}"
                                        : widget.details.status == "Cancelled"
                                            ? "₹${widget.details.totalAmount}" // Set the desired text for cancelled status
                                            : "₹${widget.details.totalAmount}",
                                style: Utils.fonts(
                                    size: 35.0,
                                    color: widget.details.status == "Pending"
                                        ? double.parse(widget
                                                    .details.totalAmount) <
                                                0
                                            ? Utils.darkRedColor
                                            : Utils.darkGreenColor
                                        : widget.details.status == "Cancelled"
                                            ? Utils
                                                .darkRedColor // Set the desired color for cancelled status
                                            : double.parse(widget
                                                        .details.totalAmount) <
                                                    0
                                                ? Utils.darkRedColor
                                                : Utils.darkGreenColor,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Client ID",
                          style: Utils.fonts(
                              size: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Utils.greyColor)),
                      Text(widget.fundTransactionModel.clientCode,
                          style: Utils.fonts(
                              size: 12.0, fontWeight: FontWeight.w700))
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Source ID",
                          style: Utils.fonts(
                              size: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Utils.greyColor)),
                      Text(widget.fundTransactionModel.clientCode,
                          style: Utils.fonts(
                              size: 12.0, fontWeight: FontWeight.w700))
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Instruction No.",
                          style: Utils.fonts(
                              size: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Utils.greyColor)),
                      Text(widget.fundTransactionModel.refNo,
                          style: Utils.fonts(
                              size: 12.0, fontWeight: FontWeight.w700))
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Instruction Date & Time",
                          style: Utils.fonts(
                              size: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Utils.greyColor)),
                      Text(
                          widget.fundTransactionModel.transactionDate
                              .toString(),
                          style: Utils.fonts(
                              size: 12.0, fontWeight: FontWeight.w700))
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
              if(widget.status == "Processed")
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // ...FundTransactionControlller.getFundTransactionList.map((item) => Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     Text("Requested Amount:",
                  //         style: Utils.fonts(
                  //             size: 14.0,
                  //             fontWeight: FontWeight.w400,
                  //             color: Utils.greyColor)),
                  //     Text(
                  //         item.amount,
                  //         style: Utils.fonts(
                  //             size: 12.0, fontWeight: FontWeight.w700))
                  //   ],
                  // )).toList(),

                ],
              ),

              const SizedBox(
                    height: 10,
                  ),
                  if (widget.status.toString().toUpperCase() == "SUCCESS")
                    Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Bank Ref. No.",
                                style: Utils.fonts(
                                    size: 14.0,
                                    fontWeight: FontWeight.w400,
                                    color: Utils.greyColor)),
                            Text("234134223",
                                style: Utils.fonts(
                                    size: 14.0, fontWeight: FontWeight.w700))
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  // if (widget.status.toString().toUpperCase() == "PENDING")
                  //   Column(
                  //     children: [
                  //       Row(
                  //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //         children: [
                  //           Text("Remark",
                  //               style: Utils.fonts(
                  //                   size: 14.0,
                  //                   fontWeight: FontWeight.w400,
                  //                   color: Utils.greyColor)),
                  //           Text("Towards Clear Balance",
                  //               style: Utils.fonts(
                  //                   size: 14.0,
                  //                   color: Utils.blackColor,
                  //                   fontWeight: FontWeight.w700))
                  //         ],
                  //       ),
                  //       SizedBox(
                  //         height: 10,
                  //       ),
                  //     ],
                  //   ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Remark",
                          style: Utils.fonts(
                              size: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Utils.greyColor)),
                      Text("Towards Clear Balance",
                          style: Utils.fonts(
                              size: 12.0, fontWeight: FontWeight.w700))
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          if (widget.fundTransactionModel.status.toString().toUpperCase() ==
              "PENDING")
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Card(
                    margin: EdgeInsets.zero,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10.0),
                            bottomLeft: Radius.circular(10.0))),
                    color: Utils.primaryColor,
                    child: InkWell(
                      onTap: () async {
                        // Navigator.pop(context);
                        var requestCollPayout = {
                          "Amount": widget.details.totalAmount,
                          "Platform_Flg": "MOBILE",

                          /// WEB/MOBILE/EXE
                          "token": Dataconstants.fundstoken,
                          "Merchant_RefNo": widget.fundTransactionModel.id ==
                                  widget.details.payOutId
                              ? widget.fundTransactionModel.refNo
                              : "",
                          //if Req_action is Modify/cancel then pass this from GetPayoutDetail
                          "Id": widget.details.payOutId,
                          //if Req_action is Modify/cancel then pass this from GetPayoutDetails ID
                          "payOutId": widget.details.payOutId,
                          //if Req_action is cancel then pass this from GetPayoutDetails ID
                          "Req_action": "Cancel"
                          //Initiate / Modify /Cancel
                        };
                        var response = await CommonFunction.getCollectPayout(
                            requestCollPayout);
                        var jsondata = json.decode(response);
                        var message = jsondata["message"];
                        CommonFunction.showBasicToast(message);
                        Navigator.pop(context);

                        CommonFunction.getpaymentstatus();
                        CommonFunction.getPaymentAccessTokenFund();
                        CommonFunction.getLastDates(1);

                        setState(() {});
                        print(message);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Utils.whiteColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10.0),
                              bottomLeft: Radius.circular(10.0)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Center(
                            child: Text("CANCEL",
                                style: Utils.fonts(
                                    size: 16.0, color: Utils.greyColor)),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Card(
                    margin: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0)),
                    ),
                    color: Utils.primaryColor,
                    child: InkWell(
                      onTap: () {
                        Dataconstants.payInModifyButton
                            ? Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => AddMoney(
                                          money: widget.fundTransactionModel
                                                      .status ==
                                                  "Pending"
                                              ? widget.details.totalAmount
                                              : widget
                                                  .fundTransactionModel.amount,
                                          fromActivity: "PayOut",
                                          type: "modify",
                                          merchantref:
                                              widget.fundTransactionModel.refNo,
                                          id: widget.details.payOutId,
                                          payOutId: widget.details.payOutId,
                                        )))
                            : null;
                        Dataconstants.payInModifyButton = false;
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Utils.primaryColor,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(10.0),
                              bottomRight: Radius.circular(10.0)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Center(
                            child: Text("MODIFY",
                                style: Utils.fonts(
                                    size: 16.0, color: Utils.whiteColor)),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )
          else if (widget.details.status
                  .toString()
                  .toUpperCase() ==
              "CANCELLED" || widget.fundTransactionModel.status
              .toString()
              .toUpperCase() ==
              "CANCELLED")
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Card(
                    margin: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10.0),
                            bottomLeft: Radius.circular(10.0))),
                    color: Utils.primaryColor,
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AddMoney(),
                            ));
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Utils.whiteColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10.0),
                              bottomLeft: Radius.circular(10.0)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Center(
                            child: Text("RETRY",
                                style: Utils.fonts(
                                    size: 16.0, color: Utils.greyColor)),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Card(
                    margin: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0)),
                    ),
                    color: Utils.primaryColor,
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => JmWatchlistScreen(),
                            ));
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Utils.primaryColor,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(10.0),
                              bottomRight: Radius.circular(10.0)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Center(
                            child: Text("HOME",
                                style: Utils.fonts(
                                    size: 16.0, color: Utils.whiteColor)),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )
          else
            SizedBox.shrink(),
        ],
      ),
    );
  }
}
